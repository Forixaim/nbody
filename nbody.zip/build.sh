#!/bin/sh
start_time=$(date +%s.%N)

set -e

# check for build flags
MODE="Release"
if [[ "$1" == "-d" ]]; then
    MODE="Debug"
elif [[ "$1" == "-p" ]]; then
    MODE="RelWithDebInfo"
fi

# compile shaders
./shaders.sh

mkdir -p build
mkdir -p bin

cmake -S . -B build -DCMAKE_BUILD_TYPE="$MODE" -G Ninja
cmake --build build -j

# output basic information
file_size=$(stat -c %s ./bin/nbody)
size_human=$(numfmt --to=iec --suffix=B "$file_size")
end_time=$(date +%s.%N)
elapsed=$(echo "$end_time - $start_time" | bc)

printf -- "-- %s build completed (%.1fs) (%s)\n" "$MODE" "$elapsed" "$size_human"

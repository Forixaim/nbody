/*
Author: Joey Soroka
Updated: 2/26/26
Purpose: Implements nbody simulation for the cpu
Comments: Switches update_cpu implementation based on compile time definitions.
Supports both AVX512 and AVX2 explicitly, all others will fall back on omp and
compiler for vectorization
*/

#include "simulation.hpp"

std::chrono::nanoseconds simulation::update_cpu(const float ft) noexcept {
    auto s = std::chrono::high_resolution_clock::now();

    attract_points(ft);
    sum_acc();
    move_points(ft);

    return std::chrono::high_resolution_clock::now() - s;
}

/// @brief Generic custom simd update function
/// @param ft Fixed time used for update
/// @return Nanoseconds it took to run update
void simulation::attract_points(const float ft) noexcept {
    data_.zero_acc();

    // aliasing
    const size_t n = data_.bodies();
    const float* __restrict ma = data_.mass();
    float* __restrict px = data_.posx();
    float* __restrict py = data_.posy();
    float* __restrict vx = data_.velx();
    float* __restrict vy = data_.vely();
    matrix& ax = data_.accx();
    matrix& ay = data_.accy();

    // TODO : test out blocked implementation to decrease pressure on ax and ay

    // gravitational constant is set to 1 for purposes of this simulation
    #pragma omp parallel
    {
        int tid = omp_get_thread_num();
        float* __restrict ax_row = ax.row(tid);
        float* __restrict ay_row = ay.row(tid);

        #pragma omp for schedule(static)
        for (size_t i = 0; i < n; i++) {
            const float p1x = px[i];
            const float p1y = py[i];
            const float p1m = ma[i];

            const auto _p1x = util::set1(p1x);
            const auto _p1y = util::set1(p1y);
            const auto _p1m = util::set1(p1m);

            auto _a1x_sum = util::zero();
            auto _a1y_sum = util::zero();

            size_t j = i+1;
            for (; j+util::last < n; j += util::width) {
                const auto _p2x = util::loadu(&px[j]);
                const auto _p2y = util::loadu(&py[j]);
                const auto _p2m = util::loadu(&ma[j]);

                // compute distance squared
                const auto _dx = _p2x - _p1x;
                const auto _dy = _p2y - _p1y;
                const auto _dsq = util::_epsl + (_dx*_dx) + (_dy*_dy);

                // fast inv sqrt with newton step
                const auto _inv = util::rsqrt(_dsq);
                const auto _inv3 = _inv * _inv * _inv;

                // compute intermediate values
                const auto _ivx = _dx * _inv3;
                const auto _ivy = _dy * _inv3;

                // compute and store accelerations
                util::storeu(&ax_row[j], util::loadu(&ax_row[j]) - (_ivx * _p1m));
                util::storeu(&ay_row[j], util::loadu(&ay_row[j]) - (_ivy * _p1m));
                _a1x_sum += _ivx * _p2m;
                _a1y_sum += _ivy * _p2m;
            }

            float a1x_final = util::hsum(_a1x_sum);
            float a1y_final = util::hsum(_a1y_sum);

            // remainder handling
            for(; j < n; j++) {
                const float p2x = px[j];
                const float p2y = py[j];
                const float p2m = ma[j];

                const float dx = p2x - p1x;
                const float dy = p2y - p1y;
                const float dsq = 1e-12f + (dx*dx) + (dy*dy);

                // fast rsqrt with netwon step
                float inv = util::frsqrt(dsq);
                inv = inv * (1.5f - 0.5f * dsq * inv * inv);

                // compute intermediate values
                float inv_dis3 = inv * inv * inv;
                float ivx = dx * inv_dis3;
                float ivy = dy * inv_dis3;

                // update acceleration values
                a1x_final += ivx * p2m;
                a1y_final += ivy * p2m;
                ax_row[j] -= ivx * p1m;
                ay_row[j] -= ivy * p1m;
            }

            ax_row[i] += a1x_final;
            ay_row[i] += a1y_final;
        }
    }
}

void simulation::sum_acc() noexcept {
    // aliasing
    matrix& ax = data_.accx();
    matrix& ay = data_.accy();
    float* __restrict ax_top = ax.row(0);
    float* __restrict ay_top = ay.row(0);

    // sum acceleration into top row
    #pragma omp parallel for simd schedule(static)
    for (size_t c = 0; c < ax.cols(); c++) {
        float sx = ax_top[c], sy = ay_top[c];

        for (size_t r = 1; r < ax.rows(); r++) {
            sx += ax(r, c);
            sy += ay(r, c);
        }

        ax_top[c] = sx;
        ay_top[c] = sy;
    }
}

void simulation::move_points(const float ft) noexcept {
    // aliasing
    const size_t n = data_.bodies();
    float* __restrict px = data_.posx();
    float* __restrict py = data_.posy();
    float* __restrict vx = data_.velx();
    float* __restrict vy = data_.vely();
    const float* ax = data_.accx().row(0);
    const float* ay = data_.accy().row(0);

    const auto _ft = util::set1(ft);
    const size_t nv = n - (n % util::width);

    #pragma omp parallel for schedule(static)
    for (size_t i = 0; i < nv; i += util::width) {
        const auto _ax = util::load(&ax[i]);
        const auto _ay = util::load(&ay[i]);
        auto _vx = util::load(vx+i);
        auto _vy = util::load(vy+i);
        auto _px = util::load(px+i);
        auto _py = util::load(py+i);

        _vx += _ax * _ft;
        _vy += _ay * _ft;
        _px += _vx * _ft;
        _py += _vy * _ft;

        util::store(vx+i, _vx);
        util::store(vy+i, _vy);
        util::store(px+i, _px);
        util::store(py+i, _py);
    }

    size_t r = n - (n%util::width);
    for (size_t i = r; i < n; i++) {
        vx[i] += ax[i] * ft;
        vy[i] += ay[i] * ft;

        px[i] += vx[i] * ft;
        py[i] += vy[i] * ft;
    }
}
